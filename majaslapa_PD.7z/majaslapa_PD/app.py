from flask import Flask, render_template, request, redirect, session
import sqlite3
import requests
from database import create_databases, insert_user, verify_user, update_email, update_password, insert_order, get_orders_by_user
 
app = Flask(__name__)
app.secret_key = "your_secret_key_here"  # Change this to a secure random key
 
RECAPTCHA_SECRET = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe"
 
def verify_recaptcha(recaptcha_response):
    """Verify reCAPTCHA token with Google"""
    if not recaptcha_response:
        return False
   
    data = {
        'secret': RECAPTCHA_SECRET,
        'response': recaptcha_response
    }
   
    try:
        response = requests.post('https://www.google.com/recaptcha/api/siteverify', data=data)
        result = response.json()
        return result.get('success', False)
    except:
        return False
 
 
@app.route("/")
def home():
    return render_template("index.html")
 
@app.route("/login", methods=["GET", "POST"])
def log_in():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]
 
        if verify_user(email, password):
            session['email'] = email
            return redirect("/dashboard")
        else:
            return "Invalid email or password", 400
 
    return render_template("log.html")
 
@app.route("/sign", methods=["GET", "POST"])
def sign_up():
    if request.method == "POST":
       
        recaptcha_token = request.form.get('g-recaptcha-response')
        if not verify_recaptcha(recaptcha_token):
            return "reCAPTCHA verification failed. Please try again.", 400
       
        email = request.form["email"]
        password = request.form["password"]
       
       
        if "terms" not in request.form:
            return "You must agree to the Terms & Conditions", 400
       
       
        if insert_user(email, password):
            return redirect("/login")
        else:
            return "Email already exists. Please use a different email.", 400
 
    return render_template("sign.html")
 
@app.route("/dashboard")
def dash():
    if 'email' not in session:
        return redirect("/login")
   
    user_email = session['email']
    return render_template("dash.html", user=user_email)
 
@app.route("/dashuser", methods=["GET", "POST"])
def dash_user():
    if 'email' not in session:
        return redirect("/login")
   
    user_email = session['email']
    message = None
    message_type = None
   
    if request.method == "POST":
        if 'new_email' in request.form and request.form['new_email']:
            new_email = request.form['new_email']
            if update_email(user_email, new_email):
                session['email'] = new_email
                message = "Email changed successfully!"
                message_type = "success"
                user_email = new_email
       
 
        if 'new_password' in request.form and request.form['new_password']:
            new_password = request.form['new_password']
            if update_password(user_email, new_password):
                message = "Password changed successfully!"
                message_type = "success"
   
    return render_template("dashuser.html", user=user_email, message=message, message_type=message_type)
 
@app.route("/dashmake")
def dash_make():
    if 'email' not in session:
        return redirect("/login")
   
    user_email = session['email']
    return render_template("dashmake.html", user=user_email)
 
@app.route("/dashorder")
@app.route("/dashorder")
def dash_order():
    if 'email' not in session:
        return redirect("/login")

    user_email = session['email']
    orders = get_orders_by_user(user_email)

    return render_template("dashorder.html", user=user_email, orders=orders)


@app.route("/order", methods=["GET","POST"])
def order():
    if 'email' not in session:
        return redirect("/login")

    user_email = session['email']

    if request.method == "POST":
        service = request.form.get('service')
        fullname = request.form.get('fullname')
        contact_email = request.form.get('email')
        company = request.form.get('company')
        timeline = request.form.get('timeline')
        budget = request.form.get('budget')
        details = request.form.get('details')

        insert_order(user_email, service, fullname, contact_email, company, timeline, budget, details)
        return redirect('/dashorder')

    return render_template("order.html", user=user_email)

 
if __name__ == "__main__":
    app.run(debug=True)