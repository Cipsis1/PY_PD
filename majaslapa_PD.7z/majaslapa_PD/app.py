from flask import Flask, render_template, request, redirect
import sqlite3
import requests

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login")
def log_in():
    return render_template("log.html")

@app.route("/dashboard")
def dash():
    return render_template("dash.html")

if __name__ == "__main__":
    app.run(debug=True)   