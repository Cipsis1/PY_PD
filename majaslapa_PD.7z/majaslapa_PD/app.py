from flask import Flask, render_template, request, redirect
import sqlite3
import requests
from database import create_databases, insert_user, verify_user
 
app = Flask(__name__)
 
RECAPTCHA_SECRET = "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe"
 
def verify_recaptcha(recaptcha_response):
    """Verify reCAPTCHA token with Google"""
    if not recaptcha_response:
        return False
   
    data = {
        'secret': RECAPTCHA_SECRET,
        'response': recaptcha_response
    }
   
    try:
        response = requests.post('https://www.google.com/recaptcha/api/siteverify', data=data)
        result = response.json()
        return result.get('success', False)
    except:
        return False
 
create_databases()
 
@app.route("/")
def home():
    return render_template("index.html")
 
@app.route("/login", methods=["GET", "POST"])
def log_in():
    if request.method == "POST":
        # Verify reCAPTCHA
        recaptcha_token = request.form.get('g-recaptcha-response')
        if not verify_recaptcha(recaptcha_token):
            return "reCAPTCHA verification failed. Please try again.", 400
       
        email = request.form["email"]
        password = request.form["password"]
 
        if verify_user(email, password):
            return redirect("/dashboard")
        else:
            return "Invalid email or password", 400
 
    return render_template("log.html")
 
@app.route("/sign", methods=["GET", "POST"])
def sign_up():
    if request.method == "POST":
        
        recaptcha_token = request.form.get('g-recaptcha-response')
        if not verify_recaptcha(recaptcha_token):
            return "reCAPTCHA verification failed. Please try again.", 400
       
        email = request.form["email"]
        password = request.form["password"]
       
       
        if "terms" not in request.form:
            return "You must agree to the Terms & Conditions", 400
       
        
        if insert_user(email, password):
            return redirect("/login")
        else:
            return "Email already exists. Please use a different email.", 400
 
    return render_template("sign.html")
 
@app.route("/dashboard")
def dash():
    return render_template("dash.html")
 
@app.route("/dashuser")
def dash_user():
    return render_template("dashuser.html")
 
@app.route("/dashmake")
def dash_make():
    return render_template("dashmake.html")
 
@app.route("/dashorder")
def dash_order():
    return render_template("dashorder.html")
 
if __name__ == "__main__":
    app.run(debug=True)  