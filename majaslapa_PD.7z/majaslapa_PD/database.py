import sqlite3
import os

# Use a deterministic DB path inside the package directory
DB_PATH = os.path.join(os.path.dirname(__file__), "users.db")
 
def create_databases():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  email TEXT NOT NULL UNIQUE,
                  password TEXT NOT NULL)''')
    c.execute('''CREATE TABLE IF NOT EXISTS orders
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  service TEXT,
                  fullname TEXT,
                  contact_email TEXT,
                  company TEXT,
                  timeline TEXT,
                  budget TEXT,
                  details TEXT,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY(user_id) REFERENCES users(id))''')
    conn.commit()
    conn.close()
 
def insert_user(email, password):
    """Insert a new user (email and password) into the database"""
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''INSERT INTO users (email, password) VALUES (?, ?)''', (email, password))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        return False
 
def verify_user(email, password):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''SELECT password FROM users WHERE email = ?''', (email,))
        result = c.fetchone()
        conn.close()
       
        if result and result[0] == password:
            return True
        else:
            return False
    except Exception as e:
        return False
 
def update_email(email, new_email):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''UPDATE users SET email = ? WHERE email = ?''', (new_email, email))
        conn.commit()
        conn.close()
        return True
    except sqlite3.IntegrityError:
        return False
 
def update_password(email, new_password):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('''UPDATE users SET password = ? WHERE email = ?''', (new_password, email))
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        return False

def insert_order(user_email, service, fullname, contact_email, company, timeline, budget, details):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT id FROM users WHERE email = ?', (user_email,))
        row = c.fetchone()
        if not row:
            conn.close()
            return False
        user_id = row[0]
        c.execute('''INSERT INTO orders (user_id, service, fullname, contact_email, company, timeline, budget, details)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                  (user_id, service, fullname, contact_email, company, timeline, budget, details))
        conn.commit()
        conn.close()
        return True
    except Exception:
        return False

def get_orders_by_user(user_email):
    try:
        conn = sqlite3.connect(DB_PATH)
        c = conn.cursor()
        c.execute('SELECT id FROM users WHERE email = ?', (user_email,))
        row = c.fetchone()
        if not row:
            conn.close()
            return []
        user_id = row[0]
        c.execute('''SELECT service, timeline, budget, created_at
                     FROM orders WHERE user_id = ? ORDER BY created_at DESC''', (user_id,))
        rows = c.fetchall()
        conn.close()
        orders = []
        for r in rows:
            orders.append({
                'service': r[0], 'timeline': r[1], 'budget': r[2], 'created_at': r[3]
        })
        return orders
    except Exception:
        return []
 
if __name__ == "__main__":
     create_databases()